const panorama = new PANOLENS.ImagePanorama('img/panorama.jpg');
const viewer = new PANOLENS.Viewer({
  container: document.querySelector('#panorama-container')
});
viewer.add(panorama);

function crearZona(tamano, tipo, x, y, z, accion) {
  const zona = new PANOLENS.Infospot(tamano, tipo);
  zona.position.set(x, y, z);
  zona.addEventListener('click', accion);
  panorama.add(zona);
}

// Zona 1 - Bienvenida
crearZona(600, PANOLENS.DataImage.Info, 1500, 200, -2000, () => {
  alert("¡Bienvenido al tour virtual!");
});

// Zona 2 - Imagen (texto de ejemplo)
crearZona(600, PANOLENS.DataImage.Info, -2000, 300, -1500, () => {
  alert('img/ambiente.jpg');
});

// Zona 3 - Video
crearZona(600, PANOLENS.DataImage.Video, 2000, 300, 1000, () => {
  window.open("https://www.youtube.com/watch?v=iC7GR26w4Gc", "_blank");
});

// Zona 4 - Audio
crearZona(600, PANOLENS.DataImage.Sound, -1200, 100, 1200, () => {
  window.open("https://youtu.be/OE9bF80KQGk?feature=shared", "_blank");
});

// Zona 5 - Texto informativo
crearZona(600, PANOLENS.DataImage.Info, 1000, 300, 2000, () => {
  alert("Esta es una oficina moderna con zonas colaborativas.");
});

// Zona 6 - Lista de opciones
crearZona(600, PANOLENS.DataImage.Info, -1500, 200, 500, () => {
  alert("Opciones:\n1. Recepción\n2. Sala de juntas\n3. Área creativa");
});

// Zona 7 - Enlace web
crearZona(600, PANOLENS.DataImage.Link, 0, 350, -2500, () => {
  window.open("https://www.concur.co/blog/article/ambiente-laboral-favorable", "_blank");
});

// Zona 8 - Cambiar fondo
crearZona(600, PANOLENS.DataImage.Info, 1200, 300, -1000, () => {
  document.body.style.backgroundColor = "#222";
});

// Zona 9 - Texto largo (salud ocupacional)
crearZona(600, PANOLENS.DataImage.Info, -2000, 250, 2500, () => {
  alert("La salud ocupacional es el área de la salud que se encarga de proteger y cuidar el bienestar físico, mental y social de los trabajadores en su ambiente de trabajo.");
});

// Zona 10 - Fin del tour
crearZona(600, PANOLENS.DataImage.Info, 0, 200, -3000, () => {
  alert("¡Gracias por hacer el recorrido!");
});
